/* 

CREATE DATABASE [Admin]
USE [Admin]

*/

/*
SELECT top 1 CustomerName FROM TripDetails
DROP TABLE TripDetails
SELECT * FROM View_TripDetails
DROP VIEW View_TripDetails;
*/

CREATE TABLE TripDetails
(
TripId BIGINT IDENTITY(1,1) PRIMARY KEY,
RideName VARCHAR(255) NOT NULL,
CustomerName VARCHAR(255) NOT NULL,
CustomerId INT,
VehicleName VARCHAR(255) NOT NULL,
NoOfSeats INT NOT NULL,
[Source] VARCHAR(255) NOT NULL,
Destination VARCHAR(255) NOT NULL,
[Date] DATE NOT NULL DEFAULT(GETDATE()),
StarTime TIME NOT NULL,
EndTime TIME,
Amount INT NOT NULL,
IsCompleted CHAR(1) DEFAULT(0)
)

INSERT INTO  TripDetails
VALUES('Trip to USA','Selva',1,'Plane2.png',1,'India','USA',GETDATE(),CONVERT(VARCHAR(8),GETDATE(),108), NULL,200000,1);

INSERT INTO  TripDetails
VALUES('Trip to Chennai','Ganapathy',2,'Bugatti-Free-PNG-Image.png',2,'Villupuram','Chennai',GETDATE(),CONVERT(VARCHAR(8),GETDATE(),108), NULL,2000,1);

INSERT INTO  TripDetails
VALUES('Trip to Banglore','Antony',3,'Mercedes-Benz-PNG-Image.png',3,'Chennai','Banglore',GETDATE(),CONVERT(VARCHAR(8),GETDATE(),108), NULL,20000,1);

INSERT INTO  TripDetails
VALUES('Trip to Mumbai','Raj',4,'Audi-PNG-Clipart.png',4,'Chennai','Mumbai',GETDATE(),CONVERT(VARCHAR(8),GETDATE(),108), NULL,30000,0);

INSERT INTO  TripDetails
VALUES('Trip to Trichy','Sibi Raj',5,'Roadster-Car.png',3,'Chennai','Trichy',GETDATE(),CONVERT(VARCHAR(8),GETDATE(),108), NULL,2000,0);

INSERT INTO  TripDetails
VALUES('Trip to Delhi','Sibi',6,'Rolls-Royce-Download-Free-PNG.png',4,'Chennai','Delhi',GETDATE(),CONVERT(VARCHAR(8),GETDATE(),108), NULL,20000,0);

INSERT INTO  TripDetails
VALUES('Trip to Kerla','Cognizant',7,'Audi-PNG-Clipart.png',3,'Villupuram','Kerla',GETDATE(),CONVERT(VARCHAR(8),GETDATE(),108), NULL,80000,1);

GO 

CREATE VIEW View_TripDetails
AS
	SELECT * FROM TripDetails;
