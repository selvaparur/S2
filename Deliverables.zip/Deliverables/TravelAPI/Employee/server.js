const express = require('express');
const constants = require('./constants');
const tripdetails =  require('./src/Infrastructure/dao/tripdetails');

const app = express();

app.use(tripdetails);

app.get('/',(req, res) =>{
    res.send("<div style='border: 2px yellow solid;margin-left: 300px; box-shadow: 10px 8px 27px 18px;;margin-right: 400px;margin-top: 200px;text-align: center;color: white;background-color: black;border-radius: 5px;height: 30px;padding-top: 10px;'>Employee API Started !!!</div>");
});

app.listen(constants.PORT,()=>{
    console.log('Employee API Started');
});
