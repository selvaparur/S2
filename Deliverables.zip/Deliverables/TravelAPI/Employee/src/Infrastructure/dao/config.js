module.exports = {
    constring : {
        server:"AZBWVSBXAASQL01.ahm.corp",
        database: "SBX_AAPROD_TEST",
        user:"SVC_AetCon_Devuser",
        password:"L0E<lK2I9#9",
        port: 1433

    }
}