const sql = require('mssql');
const config = require('./config')

module.exports = {

ExecuteQuery(strquerr, callback){

console.log('Incoming Query '+ strquerr);

   sql.connect(config.constring,(err)=>{

    if(err)
    {
        console.log('SQL Connect error => ' + err);
    }
console.log('db connected' + config.constring);
    var request = new sql.Request();

    request.query(strquerr,(err,records)=>{
if(err)
{
    console.log('Error on Query Execution => ' + err);
}
console.log('records '+ records);
sql.close();
return callback(records.recordset);

    });

    

   });

},

Test(){

}

}