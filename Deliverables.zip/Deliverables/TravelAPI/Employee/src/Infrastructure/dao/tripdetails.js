const express= require('express');
const router = express.Router();
const dao= require('./dao');

router.get('/api/tripdetails/:id',(req,res)=>{    
    var queryt = 'SELECT * FROM TripDetails WHERE CustomerId = ' + req.params.id;
    console.group('Input Param Trip Details: '+ req.params.id );
dao.ExecuteQuery(queryt, (result) =>{
    res.json(result);
});
});

module.exports = router;