module.exports = {
    PORT: 5000,
    constring:{
        
    }  
}

