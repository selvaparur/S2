const express = require('express');
const router = express.Router();
const dao = require('./dao');

// Get all the employee trip details
router.get('/api/tripdetails',(req, res)=>{
    dao.ExcuteQuery("SELECT * FROM View_TripDetails",(result)=>{        
res.status(200).json(result);
    });
});

module.exports = router;