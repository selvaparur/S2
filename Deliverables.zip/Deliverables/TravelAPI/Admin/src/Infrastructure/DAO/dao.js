const config = require('./config');
const sql = require('mssql');

module.exports = 
{

ExcuteQuery(strquery, callback)
{        
        sql.connect(config.constiring,(err)=>{
                if(err)
                {
                        console.log(err);
                }

                var request = new sql.Request();

                request.query(strquery,(err, outputresult) => {
                        if(err)
                        {
                                console.log(err);
                        }

                        sql.close();
                        console.log('db output start ');                        
                        console.log(outputresult);
                        return callback(outputresult.recordset);
                        
                });
        });

        

},

test()
{
        return "hi Selva";
}

}