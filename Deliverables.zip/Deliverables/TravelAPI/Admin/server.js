const express = require('express');
const constant = require('./src/constants');
const admindao = require('./src/Infrastructure/DAO/tripdetails');

const app = express();

app.use(admindao);

app.get('/',(req,res)=>{
res.send("<div style='border: 2px yellow solid;margin-left: 300px; box-shadow: 10px 8px 27px 18px;;margin-right: 400px;margin-top: 200px;text-align: center;color: white;background-color: black;border-radius: 5px;height: 30px;padding-top: 10px;'>Admin API Started !!!</div>");
});

app.listen(constant.PORT, () =>{
    console.log('Hi');
});