﻿using System;
using System.Collections.Generic;
using System.Text;

namespace API.Gateway
{
    public class BaseVerbs
    {
    }
}
