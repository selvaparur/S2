﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace API.Gateway
{
  public  interface IHttpVerbs
    {
      void GetAsync<T>(string mctype, ref List<T> t);       
    }
}
