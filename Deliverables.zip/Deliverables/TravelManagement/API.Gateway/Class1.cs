﻿using System;

namespace API.Gateway
{
    public class Class1
    {
    }
}
