﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace API.Gateway
{
    public class HttpVerbs : IHttpVerbs
    {
        string _strBaseURI = string.Empty;

        public HttpVerbs()
        {

        }

        public void GetAsync<T>(string mctype, ref List<T> t)
        {
            string strRoute = string.Empty;

            if (mctype.ToLower() == "admin")
            {
                string app = AppDomain.CurrentDomain.BaseDirectory;

                _strBaseURI = "http://localhost:5000/api/";
                strRoute = Constants.GetEmployeesTripDetails;
            }
            else
            {
                _strBaseURI = "http://localhost:2000/api/";
                strRoute = Constants.GetEmployeeTripDetails;

            }

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(_strBaseURI);

                // Remove & add headers
                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                // call async

              var response = client.GetAsync(strRoute).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    if (!string.IsNullOrEmpty(result))
                    {
                        t = JsonConvert.DeserializeObject<List<T>>(result);
                    }
                }
                else// error
                {

                }

            }


            //return t;
        }
    }
}
