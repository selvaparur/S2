﻿using System;
using System.Collections.Generic;
using System.Text;

namespace API.Gateway
{
   public class Constants
    {
        public static readonly string GetEmployeesTripDetails = "tripdetails";
        public static readonly string GetEmployeeTripDetails = "tripdetails/3";
    }
}
