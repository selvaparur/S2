using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TravelManagement.UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
