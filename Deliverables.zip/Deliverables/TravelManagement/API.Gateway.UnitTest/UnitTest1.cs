using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace API.Gateway.UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
