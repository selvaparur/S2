﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TravelManagement.Models;
using Microsoft.AspNetCore.Http;

namespace TravelManagement
{

    public class TMHomeController : Controller
    {
        
        public ActionResult Index(string st)
        {

            AdminTripModel tm = new AdminTripModel();
           
            return View(tm);
        }

        [HttpPost]
        public ActionResult Index1(string un)
        {

            AdminTripModel tm = new AdminTripModel();

            return View(tm);
        }
    }
}
