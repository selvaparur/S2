﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TravelManagement.Models;
using API.Gateway;

namespace TravelManagement.Controllers
{
    public class AdminSummaryController : Controller
    {
        private IHttpVerbs _httpVerbs;
        public AdminSummaryController(IHttpVerbs httpVerbs)
        {
            _httpVerbs = httpVerbs;
        }

        public IActionResult Index()
        {
            List<AdminTripModel> tm = new List<AdminTripModel>();

           _httpVerbs.GetAsync("admin",ref tm);
           


            //List<AdminTripModel> tm = new List<AdminTripModel> {
            //    new AdminTripModel { Name = "Selva", Vehicle = "BMW", NoOfSeats = 5, Source = "Guduvancher", Destination = "TCO", Date = DateTime.Now, StartTime = DateTime.Now, EndTime = DateTime.Now, Amount = 100, Completed = true, TripName="Trip To Chennai" },
            //        new AdminTripModel { Name = "Antony", Vehicle = "BMW", NoOfSeats = 5, Source = "Guduvancher", Destination = "TCO", Date = DateTime.Now, StartTime = DateTime.Now, EndTime = DateTime.Now, Amount = 100, Completed = false, TripName="Trip To Trichy" },
            //            new AdminTripModel { Name = "Raj", Vehicle = "BMW", NoOfSeats = 5, Source = "Guduvancher", Destination = "TCO", Date = DateTime.Now, StartTime = DateTime.Now, EndTime = DateTime.Now, Amount = 100 , Completed = true, TripName="Trip To Chennain"},
            //                new AdminTripModel { Name = "Ganapathy", Vehicle = "BMW", NoOfSeats = 5, Source = "Guduvancher", Destination = "TCO", Date = DateTime.Now, StartTime = DateTime.Now, EndTime = DateTime.Now, Amount = 100 , Completed = false, TripName="Trip To Cuddalore"},
            //                new AdminTripModel { Name = "Ganapathy", Vehicle = "BMW", NoOfSeats = 5, Source = "Guduvancher", Destination = "TCO", Date = DateTime.Now, StartTime = DateTime.Now, EndTime = DateTime.Now, Amount = 100 , Completed = false, TripName="Trip To Pondy"},
            //                new AdminTripModel { Name = "Ganapathy", Vehicle = "BMW", NoOfSeats = 5, Source = "Guduvancher", Destination = "TCO", Date = DateTime.Now, StartTime = DateTime.Now, EndTime = DateTime.Now, Amount = 100 , Completed = false, TripName="Trip To Vellore"},
            //                new AdminTripModel { Name = "Ganapathy", Vehicle = "BMW", NoOfSeats = 5, Source = "Guduvancher", Destination = "TCO", Date = DateTime.Now, StartTime = DateTime.Now, EndTime = DateTime.Now, Amount = 100 , Completed = false, TripName="Trip To Villupuram"}
            //};

            return View(tm);
        }       
        
    }
}