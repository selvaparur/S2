﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TravelManagement.Models;
using API.Gateway;

namespace TravelManagement.Controllers
{
    public class EmployeeSummaryController : Controller
    {
        IHttpVerbs _httpVerbs;
        public EmployeeSummaryController(IHttpVerbs httpVerbs)
        {
            _httpVerbs = httpVerbs;
        }
        public IActionResult Index()
        {
            List<EmployeeTripModel> tm = new List<EmployeeTripModel>();

            _httpVerbs.GetAsync("employee", ref tm);

            //List<AdminTripModel> tm = new List<AdminTripModel> {
            //    new AdminTripModel { Name = "Selva", Vehicle = "BMW", NoOfSeats = 5, Source = "Guduvancher", Destination = "TCO", Date = DateTime.Now, StartTime = DateTime.Now, EndTime = DateTime.Now, Amount = 100, Completed = true, TripName="Trip To Chennai" },
            //        new AdminTripModel { Name = "Antony", Vehicle = "BMW", NoOfSeats = 5, Source = "Guduvancher", Destination = "TCO", Date = DateTime.Now, StartTime = DateTime.Now, EndTime = DateTime.Now, Amount = 100, Completed = false, TripName="Trip To Trichy" },
            //            new AdminTripModel { Name = "Raj", Vehicle = "BMW", NoOfSeats = 5, Source = "Guduvancher", Destination = "TCO", Date = DateTime.Now, StartTime = DateTime.Now, EndTime = DateTime.Now, Amount = 100 , Completed = true, TripName="Trip To Chennain"}

            //};
            return View(tm);
        }
    }
}