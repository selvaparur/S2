﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TravelManagement.Models
{
    public class EmployeeTripModel
    {
        public int TripId { get;  set; }
        public string RideName { get; set; }

        public string CustomerName { get; set; }

        public int CustomerId { get; set; }
        public string VehicleName { get; set; }
        public int NoOfSeats { get; set; }
        public string Source { get; set; }
        public string Destination { get; set; }
        public DateTime Date { get; set; }
        public DateTime StartTime { get; set; }

        public DateTime? EndTime { get; set; }
        public int Amount { get; set; }
        
        public string TripName { get; set; }

        public char IsCompleted { get; set; }

    }
}
